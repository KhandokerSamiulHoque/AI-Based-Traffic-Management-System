# sans_haze_object_only > 2023-07-20 3:00pm
https://universe.roboflow.com/emergencyvehicles/sans_haze_object_only

Provided by a Roboflow user
License: CC BY 4.0

